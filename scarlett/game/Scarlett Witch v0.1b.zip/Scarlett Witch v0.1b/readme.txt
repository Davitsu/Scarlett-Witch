###########################################################################
#                                                                         #
#                           Scarlett Witch                                #
#                             For GB & GBC                                #
#                                                                         #
###########################################################################
                                                                   v0.1b

Scarlett Witch is a Game Boy and Game Boy Color game demo that I made for my final college
project. This is a very early version so you can expect many bugs and incomplete things but,
I think you can enjoy it :)

This version has 3 rooms that you have to complete by using Scarlett's special power that
lets her to change the perspective!

By the way, this is the first project I made using assembly code (RGBDS). You will need a
flash cart to try it on a real Game Boy, or you can use an emulator. I highly recommend
BGB emulator (http://bgb.bircd.org/)

Hope you like it! And, if you want to share with me some feedback, you can find me here:


Email    david.kitsu@gmail.com
Twitter  @Davitsu
Tumblr   http://davitsu.tumblr.com/

GitHub Source code - https://github.com/Davitsu/Scarlett-Witch


Code and Graphics - Davitsu
Music - AntonioND (https://github.com/AntonioND/gbt-player)